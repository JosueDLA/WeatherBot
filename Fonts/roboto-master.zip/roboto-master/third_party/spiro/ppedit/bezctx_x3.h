
bezctx *new_bezctx_x3(x3dc *dc);
void bezctx_x3_finish(bezctx *z);
