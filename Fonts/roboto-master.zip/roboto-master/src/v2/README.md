# Roboto V2 Sources
This directory contains the current masters used to generate the Roboto Sans and
Roboto Condensed families.
